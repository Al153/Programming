import CPU
import pickle #for extracting lists
class Program:
    def __init__(self):
        error = 1
        while error:
            try:
                file_name = str(raw_input("Please enter file name: "))
                self.program_file = open(file_name)
                error = 0
            except IOError:
                try:
                    file_name += '.macode'
                    self.program_file = open(file_name)
                    error = 0
                except:print "File Name Error\n\nPlease try again"
    def create_and_run(self):
        self.program = pickle.load(self.program_file)
        self.program
        self.CPU = CPU.CPU(self.program)
        self.CPU.run()


program = Program()
program.create_and_run()