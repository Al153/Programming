////////////////////////////////////////////////////////////////////////////////
//   ____  ____   
//  /   /\/   /  
// /___/  \  /   
// \   \   \/  
//  \   \        Copyright (c) 2003-2004 Xilinx, Inc.
//  /   /        All Right Reserved. 
// /---/   /\     
// \   \  /  \  
//  \___\/\___\
////////////////////////////////////////////////////////////////////////////////

#ifndef H_Work_cy62128dv30l_70_behavioral_H
#define H_Work_cy62128dv30l_70_behavioral_H
#ifdef __MINGW32__
#include "xsimMinGW.h"
#else
#include "xsim.h"
#endif


class Work_cy62128dv30l_70_behavioral: public HSim__s6 {
public:

  char *t248;
    HSim__s4 PE[15];
    HSim__s1 SE[6];

  HSimArrayType Array1base;
  HSimArrayType Array1;
    HSim__s1 SA[18];
  char t249;
  char t250;
  char t251;
  char t252;
  char *t253;
    Work_cy62128dv30l_70_behavioral(const char * name);
    ~Work_cy62128dv30l_70_behavioral();
    void constructObject();
    void constructPorts();
    void reset();
    void architectureInstantiate(HSimConfigDecl* cfg);
    virtual void vhdlArchImplement();
};



HSim__s6 *createWork_cy62128dv30l_70_behavioral(const char *name);

#endif
